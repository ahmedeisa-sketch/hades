import { SetMetadata } from '@nestjs/common';
import { UserRole } from '@prisma/client';

export const ROLES_KEY = 'roles';

/**
 * Restricts a route to the given roles.
 * Usage: @Roles(UserRole.SUPER_ADMIN, UserRole.OPERATIONS)
 */
export const Roles = (...roles: UserRole[]) => SetMetadata(ROLES_KEY, roles);
